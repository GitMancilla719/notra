<?php
// Load Composer's autoloader
require_once __DIR__ . '/vendor/autoload.php';

// Render from controller
App\Controller\HomeController::Home();
