<script setup>
import { ref, onMounted } from 'vue';
import * as faceapi from 'face-api.js';

const video = ref(null);
const recognitionStatus = ref('');
const matchingFaces = ref([]);  // Store the matched face data

const canvas = ref(null);
const capturedImage = ref(null);


// Load Face-api.js Models
const loadModels = async () => {
    await faceapi.nets.tinyFaceDetector.loadFromUri('/models');
    await faceapi.nets.faceLandmark68Net.loadFromUri('/models');
    await faceapi.nets.faceRecognitionNet.loadFromUri('/models');
    startVideo();
};

// Start Live Webcam feed
const startVideo = () => {
    navigator.getUserMedia(
        { video: {} },
        (stream) => (video.value.srcObject = stream),
        (err) => console.error(err)
    );
};

// Capture screenshot
const captureFaceData = async () => {
    const detections = await faceapi
        .detectSingleFace(video.value, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor();

    // Screenshot of new img capture
    const captureCanvas = document.createElement('canvas'); // Create an off-screen canvas element.
    captureCanvas.width = video.value.videoWidth;
    captureCanvas.height = video.value.videoHeight;
    const context = captureCanvas.getContext('2d');

    // Draw the current frame from the video onto the canvas.
    context.drawImage(video.value, 0, 0, captureCanvas.width, captureCanvas.height);

    // Convert the canvas to a data URL (Base64 string)
    capturedImage.value = captureCanvas.toDataURL('image/png');

    if (detections) {
        const faceData = detections.descriptor;
        const reqData = {
            faceData,
            base64_string: capturedImage.value
        }
        // sendTrainingData(faceData);
        sendTrainingData(reqData);
    } else {
        alert('No face detected. Please try again.');
    }


};

const sendTrainingData = (faceData) => {
    axios
        .post(route('train.store'), { faceData })
        .then((response) => alert(response.data.message))
        .catch((error) => console.error(error));
};

const recognizeFace = async () => {
    const detections = await faceapi
        .detectSingleFace(video.value, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor();

    if (detections) {
        const faceData = detections.descriptor;

        // Send face data to server for recognition
        axios
            .post(route('recognize'), { faceData })
            .then((response) => {
                recognitionStatus.value = response.data.message;
                if (response.data.matches) {
                    matchingFaces.value = response.data.matches;  // Store matching faces
                }
            })
            .catch((error) => {
                recognitionStatus.value = 'Error: ' + error.message;
            });
    } else {
        recognitionStatus.value = 'No face detected.';
    }
};

// Continuously detect faces in the video stream and attempt to recognize the reference face.
const detectFace = async () => {
    const displaySize = { width: video.value.width, height: video.value.height }; // Set display size for scaling.
    faceapi.matchDimensions(canvas.value, displaySize); // Match canvas size to video dimensions.

    // Set up a repeated detection loop every 100 ms.
    setInterval(async () => {
        // Detect all faces with landmarks and descriptors in the current video frame.
        const detections = await faceapi.detectAllFaces(video.value, new faceapi.TinyFaceDetectorOptions())
            .withFaceLandmarks()
            .withFaceDescriptors();

        // Resize the detections to match the display size.
        const resizedDetections = faceapi.resizeResults(detections, displaySize);
        canvas.value.getContext('2d').clearRect(0, 0, canvas.value.width, canvas.value.height); // Clear previous drawings.
        faceapi.draw.drawDetections(canvas.value, resizedDetections); // Draw face bounding boxes.
        faceapi.draw.drawFaceLandmarks(canvas.value, resizedDetections); // Draw facial landmarks.
    }, 100); // Run every 100ms.
}

onMounted(async () => {
    await loadModels();
    await detectFace();
});
</script>

<template>
    <div>
        <h1>Train Face Recognition</h1>
        <video ref="video" autoplay muted width="640" height="480"></video>
        <canvas ref="canvas" width="640" height="480"></canvas>

        <button @click="captureFaceData">Capture Face</button>
        <button @click="recognizeFace">Recognize Face</button>
        <p>{{ recognitionStatus }}</p>

        <!-- Display matching faces -->
        <div v-if="matchingFaces.length > 0">
            <h3>Matching Faces</h3>
            <ul>
                <li v-for="(face, index) in matchingFaces" :key="index">
                    <p>Match #{{ index + 1 }}</p>
                    <!-- <p>{{ face.face_data }}</p> -->
                    <img :src="face.demo" alt="Captured Image" width="240" height="180" />
                </li>
            </ul>
        </div>


        <div v-if="capturedImage">
            <!-- <h2>Captured Image:</h2> -->
            <img :src="capturedImage" alt="Captured Image" width="240" height="180" />
        </div>
    </div>
</template>

<style scoped>
/* video {
    width: 100%;
    height: auto;
} */
video,
canvas {
    position: absolute;
    right: 0;
    top: 100px;
}
</style>