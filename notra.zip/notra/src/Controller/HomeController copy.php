<?php

namespace App\Controller;

use App\View;

class HomeController
{
    public static function Home()
    {

        $data = [
            'title' => 'test Page',
            'message' => 'test is working'
        ];

        // Instantiate the View class to render the template
        $view = new View();
        $view->render('home/Home.twig', $data);
    }
}
