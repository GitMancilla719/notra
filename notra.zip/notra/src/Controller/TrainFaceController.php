<?php

namespace App\Controller;

use App\Database;
use Exception;

class TrainFaceController
{
    public static function Index()
    {
        try {

            echo $_SERVER['REQUEST_METHOD'];

            $db = new Database();
            $conn = $db->getConnection();

            $sql = "SELECT * FROM user_face_data";
            $result = $conn->query($sql);

            $users = [];
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $users[] = $row;
                }
            }

            // Prepare data to pass to the view
            $data = [
                'title' => 'Test Page',
                'message' => 'Test is working',
                'users' => $users
            ];

            // Render the view (assuming you have a View class to handle this)
            $view = new \App\View();
            $view->render('trainFace/TrainFace.twig');
        } catch (Exception $e) {
            // Handle the exception and display an error message
            echo "Error: " . $e->getMessage();
        }
    }
}
