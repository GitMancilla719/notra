<?php

namespace App;

use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class View
{
    private $twig;

    public function __construct()
    {
        // Set up the Twig loader and environment
        $loader = new FilesystemLoader('src/views');
        $this->twig = new Environment($loader);
    }

    // Method to render a template with data
    public function render($template, $data = [])
    {
        echo $this->twig->render($template, $data);
    }
}
