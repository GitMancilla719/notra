const MODEL_URL = "public/models";

const loadModels = async () => {
  // Load all necessary models for face detection, landmarks, and expressions
  await faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL);
  await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
  await faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL);
};

// Start the video stream from the user's camera
const startVideo = async () => {
  const video = document.getElementById("video");
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: {} });
    video.srcObject = stream;
  } catch (error) {
    console.error("Error accessing webcam:", error);
  }
};

// Set up face detection once models and video are ready
const onPlay = () => {
  const video = document.getElementById("video");
  if (!video) return;

  setInterval(async () => {
    const detections = await faceapi
      .detectAllFaces(video)
      .withFaceLandmarks()
      .withFaceExpressions();

    // Log or process detections here
    console.log(detections);
  }, 100);
};

// Initialize everything
(async () => {
  await loadModels();
  await startVideo();

  const video = document.getElementById("video");
  video.addEventListener("play", onPlay);
})();
