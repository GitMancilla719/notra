document.addEventListener("DOMContentLoaded", () => {
  const video = document.getElementById("video");
  const canvas = document.getElementById("canvas");
  const recognitionStatus = document.getElementById("recognitionStatus");
  const matchingFacesContainer = document.getElementById("matchingFaces");
  const faceList = document.getElementById("faceList");
  const capturedImageContainer = document.getElementById(
    "capturedImageContainer"
  );
  const capturedImage = document.getElementById("capturedImage");

  let matchingFaces = [];

  // Load Face-api.js Models
  const loadModels = async () => {
    await faceapi.nets.tinyFaceDetector.loadFromUri("/models");
    await faceapi.nets.faceLandmark68Net.loadFromUri("/models");
    await faceapi.nets.faceRecognitionNet.loadFromUri("/models");
    startVideo();
  };

  // Start Live Webcam feed
  const startVideo = () => {
    navigator.mediaDevices
      .getUserMedia({ video: {} })
      .then((stream) => (video.srcObject = stream))
      .catch((err) => console.error("Error accessing webcam:", err));
  };

  // Capture screenshot
  const captureFaceData = async () => {
    const detections = await faceapi
      .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceDescriptor();

    // Capture current frame as image
    const captureCanvas = document.createElement("canvas");
    captureCanvas.width = video.videoWidth;
    captureCanvas.height = video.videoHeight;
    const context = captureCanvas.getContext("2d");
    context.drawImage(video, 0, 0, captureCanvas.width, captureCanvas.height);
    const base64Image = captureCanvas.toDataURL("image/png");

    capturedImage.src = base64Image;
    capturedImageContainer.style.display = "block";

    if (detections) {
      const faceData = detections.descriptor;
      const reqData = { faceData, base64_string: base64Image };
      sendTrainingData(reqData);
    } else {
      alert("No face detected. Please try again.");
    }
  };

  const sendTrainingData = (faceData) => {
    axios
      .post("/train/store", { faceData })
      .then((response) => alert(response.data.message))
      .catch((error) => console.error(error));
  };

  const recognizeFace = async () => {
    const detections = await faceapi
      .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (detections) {
      const faceData = detections.descriptor;

      axios
        .post("/recognize", { faceData })
        .then((response) => {
          recognitionStatus.textContent = response.data.message;
          if (response.data.matches) {
            matchingFaces = response.data.matches;
            updateMatchingFaces();
          }
        })
        .catch((error) => {
          recognitionStatus.textContent = "Error: " + error.message;
        });
    } else {
      recognitionStatus.textContent = "No face detected.";
    }
  };

  const updateMatchingFaces = () => {
    faceList.innerHTML = "";
    matchingFaces.forEach((face, index) => {
      const listItem = document.createElement("li");
      listItem.innerHTML = `
                <p>Match #${index + 1}</p>
                <img src="${
                  face.demo
                }" alt="Matching Face" width="240" height="180">
            `;
      faceList.appendChild(listItem);
    });
    matchingFacesContainer.style.display = "block";
  };

  const detectFace = async () => {
    const displaySize = { width: video.width, height: video.height };
    faceapi.matchDimensions(canvas, displaySize);

    setInterval(async () => {
      const detections = await faceapi
        .detectAllFaces(video, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptors();

      const resizedDetections = faceapi.resizeResults(detections, displaySize);
      canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
      faceapi.draw.drawDetections(canvas, resizedDetections);
      faceapi.draw.drawFaceLandmarks(canvas, resizedDetections);
    }, 100);
  };

  loadModels().then(() => detectFace());

  // Event Listeners for buttons
  document
    .getElementById("captureFaceButton")
    .addEventListener("click", captureFaceData);
  document
    .getElementById("recognizeFaceButton")
    .addEventListener("click", recognizeFace);
});
