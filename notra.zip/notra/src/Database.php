<?php

namespace App;

use mysqli;
use Exception;

class Database
{
    private $host = 'localhost';
    private $username = 'root';
    private $password = 'Password12345';
    private $dbname = 'facerecog';
    private $conn;

    public function __construct()
    {
        // Attempt to connect to the MySQL database
        $this->connect();
    }

    // Database connection
    private function connect()
    {
        // Create connection
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->dbname);

        // Check connection
        if ($this->conn->connect_error) {
            // Throw an exception if connection fails
            throw new Exception("Connection failed: " . $this->conn->connect_error);
        }
    }

    // Function to return the connection object
    public function getConnection()
    {
        return $this->conn;
    }

    // Destructor to close the connection
    public function __destruct()
    {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
